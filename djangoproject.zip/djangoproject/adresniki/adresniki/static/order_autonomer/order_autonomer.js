$(document).ready(function(){
	console.log('privet kak dela')
	/*формат() как в питоне*/
    String.prototype.format = function() {
    	var newStr = this, i = 0;
    	while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

    	return newStr;
   	}

  function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }

  var csrftoken = getCookie('csrftoken');
  
  /*формат() как в питоне*/
    String.prototype.format = function() {
      var newStr = this, i = 0;
      while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

      return newStr;
    } 

   	$('#tel').inputmask({
        mask: "+7 (X99) 999-9999",
        definitions: {
            'X': {
                validator: "9",
                placeholder: "9"
            }
        }
    });

    function calculate(){
        var count = 0
        for(item in all){
          // console.log(all[item]['amount'], "item['amount']")
          count = count + all[item]['amount']
        }

        $('#count').text(count);
        $('#costValue').text(count * 300)
    }

    // написать добавление при загрузке из массива all в корзину
    // all = [
    // {nomer: "3aef", code: "222", amount: 2},
    // {nomer: "34d", code: "122", amount: 2},
    // {nomer: "3aw", code: "332", amount: 2},
    // {nomer: "aaaa", code: "444", amount: 2},
    // {nomer: "rrrr", code: "777", amount: 2},
    // {nomer: "rrrr", code: "777", amount: 4},
    // ]
    // console.log(all)

    if (all.length != 0){
        console.log('!=0')
        $('.howmany').show()
        $('.costall').show()
        $('.motivation').hide()
        calculate()
        for(elem in all){
          console.log(all[elem])
          addbasketprice(all[elem])
        }
    }

    function addbasketprice(newnomer){
    console.log(newnomer)

    var htmltext = '<div class="box2">\
        <div class="big2">\
          <div class="seven2">\
            <span>%s</span>\
          </div>\
          <div class="two2">\
            <div class="area2">\
              <span>%s</span>\
            </div>\
            <div class="flag2"><img src="/static/nomer/flag.jpg"></div>\
          </div>\
        </div>\
        <div class="go2">\
          <div class="calc2">\
            <div class="amount2"><span>%s</span> шт.</div>\
            <div class="piece22">300 &#8381;/шт.</div>\
          </div>\
          <div class="overPrice2"><span>%s</span> &#8381;</div>\
        </div>\
        <div class="delete"><span >Удалить</span></div>\
        <div class="clearfix"></div>\
      </div>'.format(newnomer['nomer'], newnomer['code'], newnomer['amount'], newnomer['amount'] * 300)

    // console.log(htmltext)
    $(".forbox").append(htmltext)
  }

  // for(elem in all){
  //   console.log(all[elem])
  //   addbasketprice(all[elem])
  // }

  //дописать появление общей стоимости общее количество
  

  //удаление из корзины
  $('.forbox').on('click', '.delete span', function(){
        console.log($(this).parent().parent(), $(this).parent().parent().index())
        var ind = $(this).parent().parent().index()
        console.log(ind, all)
        all.splice(ind, 1)
        $(this).parent().parent().remove()
        console.log(all) 
        calculate()
        $.post(
           "/changeallnomer/",
           {
             "csrfmiddlewaretoken" : csrftoken,
             'datanomer': JSON.stringify(all)
           },
           function(){
            // console.log('добавлено')
            
           }
        ); 
        if(all.length == 0){
            $('.motivation').show()
        }
  })
})