$(document).ready(function(){
	console.log('privet kak dela1')

  // возвращает куки с указанным name,
  // или undefined, если ничего не найдено
  function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }

  var csrftoken = getCookie('csrftoken');
  
	/*формат() как в питоне*/
    String.prototype.format = function() {
    	var newStr = this, i = 0;
    	while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

    	return newStr;
   	}

  function calculate(){
    var count = 0
    for(item in all){
      // console.log(all[item]['amount'], "item['amount']")
      count = count + all[item]['amount']
    }
    $('#count').text(count);
    $('#costValue').text(count * 300)
  }

  function addbasketprice(newnomer){
    console.log(newnomer)

    var htmltext = '<div class="box2">\
        <div class="big2">\
          <div class="seven2">\
            <span>%s</span>\
          </div>\
          <div class="two2">\
            <div class="area2">\
              <span>%s</span>\
            </div>\
            <div class="flag2"><img src="/static/nomer/flag.jpg"></div>\
          </div>\
        </div>\
        <div class="go2">\
          <div class="calc2">\
            <div class="amount2"><span>%s</span> шт.</div>\
            <div class="piece22">300 &#8381;/шт.</div>\
          </div>\
          <div class="overPrice2"><span>%s</span> &#8381;</div>\
        </div>\
        <div class="delete"><span >Удалить</span></div>\
        <div class="clearfix"></div>\
      </div>'.format(newnomer['nomer'], newnomer['code'], newnomer['amount'], newnomer['amount'] * 300)

    // console.log(htmltext)
    $(".forbox").append(htmltext)
  }

  class classNomer{
    constructor(nomer, code, amount){
      this.nomer = nomer,
      this.code = code,
      this.amount = amount
    }
  }

  // all = []

  for(elem in all){
    console.log(all[elem])
    addbasketprice(all[elem])
  }
  calculate()

  //обработка кнопки добавить в корзину 
  $('#button-basket button').click(function(){


    if($('#textUp').val().length != 0 && $('#textDown').val().length != 0){
      $('#textUp').removeClass('shadowinpt')
      $('#textDown').removeClass('shadowinpt')
      
      newnomer = new classNomer($('#textUp').val(), $('#textDown').val(), parseInt($('.amountInput').val()))
    

      console.log('create', all)
    
      var keep = false
      //проверка есть ли такой дизайн
      for(item in all){

        if(JSON.stringify(all[item]) === JSON.stringify(newnomer)){
          keep = true
          console.log('trueeee')
        }
      }

      if(keep == true){
        console.log('такой дизайн уже есть в корзине')

        $('.howmany').addClass('weighthowmany');

        setTimeout(() => {
            $('.howmany').removeClass('weighthowmany')
          }, 1000);

      }else{ 
        all.push(newnomer)
        
        // $('#count').text(all.length)
        // $('#costValue').text(all.length * 300)
        $('.howmany').show()
        $('.costall').show()
        $('.motivation').hide()

        addbasketprice(newnomer)
        //обработка кнопки добавить в корзину
        $.post(
         "/changeallnomer/",
         {
           "csrfmiddlewaretoken" : csrftoken,
           'datanomer': JSON.stringify(all)
         },
         function(){
          // console.log('добавлено')
          
         }
        ); 

      }

    }else{
      console.log('где-то пусто')
      if($('#textUp').val().length == 0){

        $('#textUp').addClass('shadowinpt')
      
      }else{
        $('#textUp').removeClass('shadowinpt')
      }

      if($('#textDown').val().length == 0){
        $('#textDown').addClass('shadowinpt')
      }else{
        $('#textDown').removeClass('shadowinpt')
      }

    }
  console.log('create', all)
  calculate()   
  })


  //ловит изменение значения в select
  // $('select.amount').on('change', function() {
      
  //     var amountLength = parseInt(this.value)
      
  //     if(this.value == '3+'){
  //       //показать input, где можно писать только цифры
       
  //       $(this).hide()
  //       $(this).parent().children('.amountInput').show()
  //       $(this).parent().children('.amountInput').val('2')
       
  //     }else{
        
  //       $('.overPrice').text(amountLength * 300)
  //     }

  //     console.log(amountLength)

  // });

  //ловит изменение значения в input количество штук

  $('.amountInput').on('change', function(){
    
    var value = parseInt(this.value)   
    
    if(value >= 2 && value <= 10){

        $('.overPrice').text(value * 300)

    }
    //просчитать новое значение количества и сумму в корзине
   
    console.log(value)
      
  })

  //удаление из корзины
  // $('.delete span').click(function(){
  //   console.log($(this).parent().parent())
  // })

  $('.forbox').on('click', '.delete span', function(){
    console.log($(this).parent().parent(), $(this).parent().parent().index())
    
    var ind = $(this).parent().parent().index()
    console.log(ind, all)
    all.splice(ind, 1)
    $(this).parent().parent().remove()
    console.log(all) 
    calculate()
    $.post(
         "/changeallnomer/",
         {
           "csrfmiddlewaretoken" : csrftoken,
           'datanomer': JSON.stringify(all)
         },
         function(){
          // console.log('добавлено')
          
         }
        ); 
    if(all.length == 0){
      $('.motivation').show()
    }

  })

    
})