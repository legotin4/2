$(document).ready(function(){
	console.log('privet kak dela1')

  // возвращает куки с указанным name,
  // или undefined, если ничего не найдено
  function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }

  var csrftoken = getCookie('csrftoken');
  
	/*формат() как в питоне*/
    String.prototype.format = function() {
    	var newStr = this, i = 0;
    	while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

    	return newStr;
   	}

  maxValueSlider = 100
  baseFromPrice = $('input[name="base"]:checked').val()
  textOrNumbersfromPrice = $('input[name="text-numbers-radio"]:checked').val()

  prices = {
        'keys2 text' : 170,
        'keys2 numbers' : 80, 
        'cloakroom2 numbers' : 80,
        'bind2 numbers' : 80
      }

  $('.overPrice').text(prices['keys2 text'] * parseInt($('.amountInput').val()))

  $( "#slider-range" ).slider({
    range: true,
    min: 1,
    max: maxValueSlider,
    values: [ 10, 32 ],
    slide: function( event, ui ) {
      
      //подставляет при изменении 
      $('.from').text(' '+ ui.values[0])
      $('.to').text(' '+ ui.values[1])
      
      console.log('количество:', ui.values[1] - ui.values[0])
      baseFromPrice = $('input[name="base"]:checked').val()
      textOrNumbersfromPrice = $('input[name="text-numbers-radio"]:checked').val()
      console.log(baseFromPrice, textOrNumbersfromPrice)
    
      var keyvalue = baseFromPrice + ' ' + textOrNumbersfromPrice
      console.log(prices[keyvalue])
      var pieces = (ui.values[1] - ui.values[0]) + 1
      $('.overPrice').text(parseInt(pieces) * prices[keyvalue])
      $('#calc-value').text(pieces)
      $('#another-piece-value').text(prices[keyvalue])

      if(ui.values[1] == 100 && addRangeClick < 4){
        console.log('100!')
        $('.jq-slider-add-range').show()
      }
      
    }
  });



    //валью в массиве подставляет на страницу
  $('.from').text(' ' + $( "#slider-range" ).slider("values", 0))
  $('.to').text(' ' + $( "#slider-range" ).slider("values", 1))
  $('.slide-left').text(' ' + $( "#slider-range" ).slider("values", 0))
  $('.slide-right').text(maxValueSlider)
  $('#calc-value').text(($( "#slider-range" ).slider("values", 1) - $( "#slider-range" ).slider("values", 0)) + 1)

  //обработки кнопки добавления диапазона для слайдера 
  addRangeClick = 1
  $('.add-range').click(function(){

    addRangeClick += 1
    console.log(addRangeClick)
    

    if(addRangeClick < 3){
      maxValueSlider += 100
    }else if(addRangeClick == 3){
      maxValueSlider += 100
      $('.add-range').val('999')
      // maxValueSlider = 999
    }else if(addRangeClick > 3){
      maxValueSlider = 999
      $('.jq-slider-add-range').hide()
    }

    $( "#slider-range" ).slider({
      max:maxValueSlider
    })
    $('.slide-right').text(maxValueSlider)
    $('.to').text(' ' + maxValueSlider)

  })


  //обрабатывает изменение текст или цифры 
  $('.text-numbers-radio').change(function(){

    var valueinput = this.value
    showKeys2textValue()
    var form = $('input[name="form-radio"]:checked').val()
    console.log(valueinput, form)
    $('.text-numbers-sub').children().each(function(){
      if($(this).hasClass(valueinput)){
        $(this).show()
      }else{
        $(this).hide()
      }
    })

    if(valueinput == 'text'){
      $('.div-slider').hide()
      $('.text').children().each(function(){
        if($(this).hasClass(form)){
            $(this).show()
        }else{
            $(this).hide()
        }
      })
    }else{
      console.log('div-slider')
      $('.div-slider').show()
      $('.numbers').children().each(function(){
        if($(this).hasClass(form)){
            $(this).show()
        }else{
            $(this).hide()
        }
      })
    }
    textOrNumbersfromPrice = $('input[name="text-numbers-radio"]:checked').val()
  })

  //обрабатывает изменение форм
  $('.form-radio').change(function(){
    var valueinput = this.value
    //получить 
    var textOrNumbers = $('input[name="text-numbers-radio"]:checked').val() 
    console.log($('input[name="text-numbers-radio"]:checked').val(), valueinput)
    
    if(textOrNumbers == 'text'){
      console.log('div-slider hide')
      $('.div-slider').hide()
      $('.text').children().each(function(){
        if($(this).hasClass(valueinput)){
            $(this).show()
        }else{
            $(this).hide()
        }
      })
    }else{
      //numbers
      console.log('div-slider show')
      $('.div-slider').show()
      $('.numbers').children().each(function(){
        if($(this).hasClass(valueinput)){
            $(this).show()
        }else{
            $(this).hide()
        }
      })

    }

  })

  //обрабатывает измение базы: для ключей, номерки или таблички
  $('.base-radio').change(function(){
    var valueinput = this.value

    $('.choice-base-show').children().each(function(){
     if($(this).hasClass(valueinput)){
        $(this).show()
      }else{
        $(this).hide()
      } 
    })

    if((valueinput == 'cloakroom2') || (valueinput == 'bind2')){
      console.log('div-slider show')
      $('.div-slider').show()
      $("#numbers").prop('checked', true)
      $('input[name="text-numbers-radio"]').prop('disabled', true);
      $('#circle').prop('checked', true)
    }else{
      console.log('div-slider hide')
      $('.div-slider').hide()
      $('#text').prop('checked', true)
      $('#circle').prop('checked', true)
      $('input[name="text-numbers-radio"]').prop('disabled', false);
    }

    
    baseFromPrice = $('input[name="base"]:checked').val()
    showKeys2textValue()
    passRadioAndShowDiv()
  })


  all = []

  class classBase{
    constructor(base, textOrNumbers, format, from, to, text, amount){
      this.base = base, 
      this.textOrNumbers = textOrNumbers,
      this.format = format,
      this.from = from,
      this.to = to,
      this.text = text
      this.amount = amount 
    }
  }

  //при по добваление в корзину сравнивает значение объекта и подставляет нужный ксс-класс

  back = {
    'keys2 text circle2': 'back-keys-circle', 
    'keys2 text sq2': 'back-keys-sq',
    'keys2 text rect2': 'back-keys-rect2',

    'keys2 numbers circle2': 'back-keys-circle',
    'keys2 numbers sq2': 'back-keys-sq',
    'keys2 numbers rect2': 'back-keys-rect2',

    'cloakroom2 numbers circle2': 'back-cloakroom-circle',
    'cloakroom2 numbers sq2': 'back-cloakroom-sq',
    'cloakroom2 numbers rect2': 'back-cloakroom-rect2',

    'bind2 numbers circle2': 'back-nameplate-circle',
    'bind2 numbers sq2': 'back-nameplate-sq',
    'bind2 numbers rect2': 'back-nameplate-rect2'
  }

  nameBase = {
    'keys2':'Для ключей',
    'cloakroom2':'Номерки',
    'bind2':'Для крепления'
  }

  //создаёт объект и добавляет в all
  $('.create').click(function(){
    var base = $('input[name="base"]:checked').val()
    var textOrNumbers = $('input[name="text-numbers-radio"]:checked').val()
    var format = $('input[name="form-radio"]:checked').val()
    // var createOrder = false

    if(textOrNumbers == 'numbers'){
      var from = $( "#slider-range" ).slider("values", 0)
      var to = $( "#slider-range" ).slider("values", 1)
      var text = false
      var amount = (($( "#slider-range" ).slider("values", 1) - $( "#slider-range" ).slider("values", 0)) + 1)
      if(amount < 10){
        console.log('меньше 10')

      }else{
        console.log('больше 10')
        // createOrder = true
        newex = new classBase(base, textOrNumbers, format, from, to, text, amount)
        all.push(newex)
        $('.howmany').show()
        $('.costall').show()
        $('.motivation').hide()
        addbasketprice(newex)
        calculate()  
      }
    }else{
      console.log('its text', $('input[name="basetext"]:visible').val())
      if($('input[name="basetext"]:visible').val().length != 0){
        var from = false
        var to = false
        var text = $('input[name="basetext"]:visible').val()
        var amount = parseInt($('input[name="amountInput"]:visible').val())
        newex = new classBase(base, textOrNumbers, format, from, to, text, amount)
        all.push(newex)
        $('.howmany').show()
        $('.costall').show()
        $('.motivation').hide()
        addbasketprice(newex)
        calculate()  
      }else{
        console.log('== 0')

      }  
    }

    // newex = new classBase(base, textOrNumbers, format, from, to, text, amount) 
    // console.log('создано', newex)
    // all.push(newex) 
    // console.log('добавлено', all, all.length)


    // $('.howmany').show()
    // $('.costall').show()
    // $('.motivation').hide()
    // addbasketprice(newex)
    // calculate()
  })

  function passRadioAndShowDiv(){
    var base = $('input[name="base"]:checked').val()
    var textOrNumbers = $('input[name="text-numbers-radio"]:checked').val()
    var format = $('input[name="form-radio"]:checked').val()

    $('.text-numbers-sub').children().each(function(){
      if($(this).hasClass(textOrNumbers)){
        $(this).show()
      }else{
        $(this).hide()
      }
    })
    if(textOrNumbers == 'text'){
      $('.text').children().each(function(){
        if($(this).hasClass('circle2')){
            console.log('circle2 text должен показаться ', $(this))
            $(this).show()
        }else{
            $(this).hide()
        }
      })
    }else{
      //numbers
      $('.numbers').children().each(function(){
        if($(this).hasClass('circle2')){
            $(this).show()
        }else{
            $(this).hide()
        }
      })

    }
  }

  //ловит изменение значения в input количество штук
  $('.piece-value').text(prices['keys2 text'])

  $('.amountInput').on('change', function(){
    var value = parseInt(this.value)

    if(value >= 2 && value <= 10){
      $('.overPrice').text(value * prices['keys2 text'])
    }   
  })
  $('.another').hide()
  //скрывает\показывает калькуляторы для текстовых или числовых брелков
  function showKeys2textValue(){
    var textOrNumbers = $('input[name="text-numbers-radio"]:checked').val()
    var base = $('input[name="base"]:checked').val()
    var key = base + ' ' + textOrNumbers
    // var format = $('input[name="form-radio"]:checked').val()
    if(textOrNumbers == 'text'){
      console.log('showKeys2textValue text')
      $('.keys2-text').show()
      $('.another').hide()
      $( ".choice-base-show" ).addClass("width260px")
      $( ".choice-base-show" ).removeClass("width420px")

    }else{

      $('.another').show()
      $('.keys2-text').hide()
      $('.another-piece-value').text(prices[key])
      $( ".choice-base-show" ).addClass("width420px")
      $( ".choice-base-show" ).removeClass("width260px")
      var value = ($( "#slider-range" ).slider("values", 1) - $( "#slider-range" ).slider("values", 0)) + 1
      $('.overPrice').text(prices[key] * value)
    }
  }

  function addbasketprice(newex){
    console.log(newex.base, newex.textOrNumbers, newex.format)
    var getvalue = newex.base + ' ' + newex.textOrNumbers + ' ' + newex.format
    var cssName = back[getvalue]

    var from = newex.from
    var to = newex.to
    var text = newex.text
    var amount = newex.amount
    var priceValue = amount * prices[newex.base + ' ' + newex.textOrNumbers]
    // console.log(back[getvalue], getvalue)

    //в шаблоне пишутся два дива для заказа с текст и числами
    //чтобы в браузере не показывать два дива - эта фича
    var csshidetext = 'hide'
    var csshidenumbers = 'hide'
    
    if(newex.textOrNumbers == 'text'){
      csshidetext = ''
      
    }else{
      csshidenumbers = ''
      
    }

    var htmltext = '<div class="box2">\
        <div class="big2">\
          <div class="back %s">\
          </div>\
          <div class="big2-about">\
            <div class="big2-base">%s</div>\
            <div class="big2-text %s"> %s</div>\
            <div class="big2-numbers %s">\
              Большие цифры<br>\
              <span class="big2-from">%s</span> - <span class="big2-to">%s</span>\
            </div>\
          </div>\
        </div>\
        <div class="go2">\
          <div class="calc2">\
            <div class="amount2"><span>%s</span> шт.</div>\
            <div class="piece22">%s &#8381;/шт.</div>\
          </div>\
          <div class="overPrice2"><span>%s</span> &#8381;</div>\
        </div>\
        <div class="clearfix"></div>\
        <div class="delete"><span >Удалить</span></div>\
      </div>\
    '.format(cssName, nameBase[newex.base], csshidetext, text, csshidenumbers, from, to, amount, prices[newex.base + ' ' + newex.textOrNumbers], priceValue)
    
    // console.log(htmltext)
    $(".forbox").append(htmltext)
  }

  //подсчет общей цены в корзине и количества
  function calculate(){
    var valuePrice = 0
    var valueAmount = 0
    for(item in all){
      valuePrice =  valuePrice + all[item]['amount'] * prices[all[item]['base'] + ' ' + all[item]['textOrNumbers']]
      valueAmount = valueAmount + all[item]['amount']
    }
    $('#count').text(valueAmount);
    $('#costValue').text(valuePrice)
  }

  //обработк удаления в корзине
  $('.forbox').on('click', '.delete span', function(){
    console.log($(this).parent().parent(), $(this).parent().parent().index())
    
    var ind = $(this).parent().parent().index()
    // console.log(ind, all)
    all.splice(ind, 1)

    $(this).parent().parent().remove()
    // console.log(all) 
    calculate()
    
    if(all.length == 0){
      $('.motivation').show()
    }
    
  })

})