$(document).ready(function(){
	console.log('privet kak dela')
	/*формат() как в питоне*/
    String.prototype.format = function() {
    	var newStr = this, i = 0;
    	while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

    	return newStr;
   	}

   	$('#tel').inputmask({
        mask: "+7 (X99) 999-9999",
        definitions: {
            'X': {
                validator: "9",
                placeholder: "9"
            }
        }
    });
})