$(document).ready(function(){
	console.log('privet kak dela1')

  // возвращает куки с указанным name,
  // или undefined, если ничего не найдено
  function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }

  var csrftoken = getCookie('csrftoken');
  
	/*формат() как в питоне*/
    String.prototype.format = function() {
    	var newStr = this, i = 0;
    	while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

    	return newStr;
   	}

  function calculate(){
    var count = 0
    for(item in all){
      console.log(all[item]['amount'], "item['amount']")
      count = count + all[item]['amount']
    }
    $('#count').text(count);
    $('#costValue').text(count * 300)
  }

  class classAddress{
    constructor(nomer, code, amount){
      this.nomer = nomer,
      this.code = code,
      this.amount = amount
    }
  }

  all = []

  //обработка кнопки добавить в корзину 
  $('#button-basket button').click(function(){


    if($('#textUp').val().length != 0 && $('#textDown').val().length != 0){
      $('#textUp').removeClass('shadowinpt')
      $('#textDown').removeClass('shadowinpt')

      if($('.amountInput').css('display') == 'none'){
        console.log($('.amount').val())
        if($('.amount').val() == '3+'){
          amount = 2
        }else{
          amount = parseInt($('.amount').val())
        }
      }else if($('.amount').css('display') == 'none'){
        console.log($('.amountInput').val())
        amount = parseInt($('.amountInput').val())
      }

      newaddress = new classAddress($('#textUp').val(), $('#textDown').val(), amount)
    

      console.log('create', all)
    
      var keep = false
      //проверка есть ли такой дизайн
      for(item in all){
        // console.log(all[item], 'for', newaddress)

        if(JSON.stringify(all[item]) === JSON.stringify(newaddress)){
          keep = true
          console.log('trueeee')
        }
      }

      if(keep == true){
        console.log('такой дизайн уже есть в корзине')

        $('.howmany').addClass('weighthowmany');

        setTimeout(() => {
            $('.howmany').removeClass('weighthowmany')
          }, 1000);

      }else{
        all.push(newaddress)
        
        $('#count').text(all.length)
        $('#costValue').text(all.length * 450)
        $('.howmany').show()
        $('.costall').show()
        $('.motivation').hide()

        //обработка кнопки добавить в корзину
        // $.post(
        //  "/changeall/",
        //  {
        //    "csrfmiddlewaretoken" : csrftoken,
        //    'data': JSON.stringify(all)
        //  },
        //  function(){
        //   // console.log('добавлено')
          
        //  }
        // ); 
      }
      
      // if(all.length > 1){

      // }

    }else{
      console.log('где-то пусто')
      if($('#textUp').val().length == 0){

        $('#textUp').addClass('shadowinpt')
      
      }else{
        $('#textUp').removeClass('shadowinpt')
      }

      if($('#textDown').val().length == 0){
        $('#textDown').addClass('shadowinpt')
      }else{
        $('#textDown').removeClass('shadowinpt')
      }

    }
  console.log('create', all)
  calculate()   
  })


  //ловит изменение значения в select
  $('select.amount').on('change', function() {
      // $('input[name="city"]').val();
      var amountLength = parseInt(this.value)
      
      // console.log(typeof(this.value), this.value)
      
      if(this.value == '3+'){
        //показать input, где можно писать только цифры
        // $('.UpOverPriceText').show()
        // $(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').show()
        $(this).hide()
        $(this).parent().children('.amountInput').show()
        $(this).parent().children('.amountInput').val('2')
        // $(this).parent().parent().children('.UpOverPrice').children('.overPrice').text(parseInt($(this).parent().children('.amountInput').val()) * 450) 
        // $(this).parent().children('.piece').show()
        // console.log(1, $('.item').index($(this).parent().parent()))
        
        // all[all.length - 1]['amount'] = 2


        // data[$('.item').index($(this).parent().parent())]['amount'] = 1
        // console.log(data[$('.item').index($(this).parent().parent())])

        // $('#dataform').val(JSON.stringify(data))
      }else{
        // 
        // console.log(amountLength, $('.item').index($(this).parent().parent()))


        // all[all.length - 1]['amount'] = amountLength

        // $('#dataform').val(JSON.stringify(data))
        // console.log(data[$('.item').index($(this).parent().parent())]) 
        // $(this).parent().parent().children('.UpOverPrice').children($'.overPrice').text(amountLength * 450)
        $('.overPrice').text(amountLength * 300)
      }

      // if(amountLength > 1){
        // console.log('ttttt')
        // $(this).parent().children('.piece').show()
        // $(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').show()
      // }else{
        // $(this).parent().children('.piece').hide()
        // $(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').hide()

      // }

      console.log(amountLength)
      //просчитать новое значение количества и сумму в корзине
      // calculate()   

  });

  //ловит изменение значения в input 
  $('.amountInput').on('change', function(){
    
    var value = parseInt(this.value)
    // console.log(value)   
    // data[$('.item').index($(this).parent().parent())]['amount'] = value
    // console.log(data[$('.item').index($(this).parent().parent())])
    // console.log(data)
    // $('#dataform').val(JSON.stringify(data))
    
    
    if(value >= 2 && value <= 10){
        
        // $(this).parent().parent().children('.UpOverPrice').children('.overPrice').text(value * 450)
        $('.overPrice').text(value * 300)

        // if(value == 1){
        //   $(this).parent().children('.piece').hide()
        //   $(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').hide()
        //    }else{
        //       $(this).parent().children('.piece').show()
        //       $(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').show()
        //  }
    }
    //просчитать новое значение количества и сумму в корзине
    // calculate() 
    console.log(value)
      
  })

    
})