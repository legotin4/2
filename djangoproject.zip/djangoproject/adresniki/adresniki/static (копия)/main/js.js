$(document).ready(function(){
	console.log('privet kak dela')
  // возвращает куки с указанным name,
  // или undefined, если ничего не найдено
  function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }

  var csrftoken = getCookie('csrftoken');
	// console.log(csrftoken, 'getCookie()')
  /*формат() как в питоне*/
    String.prototype.format = function() {
    	var newStr = this, i = 0;
    	while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

    	return newStr;
   	}

  function changeImgForm(){
    if($('#oval').prop('checked')){
      console.log('oval')
      
      $('#tabletopOval').removeClass('hidden')
      $('#tabletopCircle').addClass('hidden')
      $('#tabletopRect').addClass('hidden')
      $('.textfortag').css({'width': '227px', 'left': '35px'})

    }else if($('#circle').prop('checked')){
      console.log('circle')

      $('#tabletopOval').addClass('hidden')
      $('#tabletopCircle').removeClass('hidden')
      $('#tabletopRect').addClass('hidden')
      $('.textfortag').css({'width': '170px', 'left': '65px'})

    }else if($('#rect').prop('checked')){
      console.log('rect')

      $('#tabletopOval').addClass('hidden')
      $('#tabletopCircle').addClass('hidden')
      $('#tabletopRect').removeClass('hidden')
      $('.textfortag').css({'width': '227px', 'left': '35px'})

    }
  }

 	$('.formtag').change(function(){

 		changeImgForm()

 	})

  // $("#button-basket button").attr("disabled", "disabled"); 
  $("#changeArray button").attr("disabled", "disabled"); 


  //ловит изменения инпутов
  $('.change').on("input",function(ev){
    // console.log($(ev.target).val());
    $("#button-basket button").removeAttr("disabled")
    $("#changeArray button").removeAttr("disabled", "disabled");
  });

  class classAddress{
    constructor(form, color, textup, textdown){
      this.form = form,
      this.color = color,
      this.textup = textup,
      this.textdown = textdown,
      this.amount = 1
    }
  }

  //обработка кнопки добавить в корзину 
  $('#button-basket button').click(function(){

    if($('#textUp').val().length != 0 && $('#textDown').val().length != 0){
      $('#textUp').removeClass('shadowinpt')
      $('#textDown').removeClass('shadowinpt')

      newaddress = new classAddress($('.formtag:checked').val(), $('.color:checked').val(), $('#textUp').val(), $('#textDown').val())
    

      console.log('create', all)
    
      var keep = false
      //проверка есть ли такой дизайн
      for(item in all){
        console.log(all[item], 'for', newaddress)

        if(JSON.stringify(all[item]) === JSON.stringify(newaddress)){
          keep = true
          console.log('trueeee')
        }
      }

      if(keep == true){
        console.log('такой дизайн уже есть в корзине')

        $('.howmany').addClass('weighthowmany');

        setTimeout(() => {
            $('.howmany').removeClass('weighthowmany')
          }, 1000);

      }else{
        all.push(newaddress)
        
        $('#count').text(all.length)
        $('#costValue').text(all.length * 450)
        $('.howmany').show()

        //обработка кнопки добавить в корзину
        $.post(
         "/changeall/",
         {
           "csrfmiddlewaretoken" : csrftoken,
           'data': JSON.stringify(all)
         },
         function(){
          // console.log('добавлено')
          
         }
        ); 
      }
      
      if(all.length > 1){
        $('.costall').show()
      }

    }else{
      console.log('где-то пусто')
      if($('#textUp').val().length == 0){

        $('#textUp').addClass('shadowinpt')
      
      }else{
        $('#textUp').removeClass('shadowinpt')
      }

      if($('#textDown').val().length == 0){
        $('#textDown').addClass('shadowinpt')
      }else{
        $('#textDown').removeClass('shadowinpt')
      }

    }
    
  })
  
  //обработка кнопки изменить адресник
  //получение из getall данных об том, что в корзине 
  $('#changeArray button').click(function(){
    // console.log('changeArray click')
    // console.log(all[changeNumber1])
    $.post(
         "/getall/",
         {
           "csrfmiddlewaretoken" : csrftoken,
         },
         changeAll
       );
  })

  function changeAll(data){
    newaddress = new classAddress($('.formtag:checked').val(), $('.color:checked').val(), $('#textUp').val(), $('#textDown').val())
    
    data[changeNumber1] = newaddress

    //отправка новых значений data
    $.post(
         "/changeall/",
         {
           "csrfmiddlewaretoken" : csrftoken,
           'data': JSON.stringify(data)
         },
         function(){
          console.log('новый дизайн добавлен в корзину')
          //изменить баттон на добавить в корзину
          $('#button-basket').removeClass('hidden')
          $('#changeArray').addClass('hidden')
          $("#button-basket button").attr("disabled", "disabled"); 
          
         }
       ); 
  }

  if(typeof textUp1 !== 'undefined'){

    $('#textUp').val(textUp1)
    $('#textDown').val(textDown1)

    if(formtag1 == 'oval'){
      $('#oval').attr('checked', true);
    }else if(formtag1 == 'circle'){
      $('#circle').attr('checked', true);
    }else if(formtag1 == 'rect'){
      $('#rect').attr('checked', true);
    }

    changeImgForm()
  }


  
  
 	
})