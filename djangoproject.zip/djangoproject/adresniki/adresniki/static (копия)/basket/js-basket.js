$(document).ready(function(){
	console.log('privet kak dela')

  // возвращает куки с указанным name,
  // или undefined, если ничего не найдено
  function getCookie(name) {
    let matches = document.cookie.match(new RegExp(
      "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
    ));
    return matches ? decodeURIComponent(matches[1]) : undefined;
  }

  var csrftoken = getCookie('csrftoken');
  
	/*формат() как в питоне*/
    String.prototype.format = function() {
    	var newStr = this, i = 0;
    	while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

    	return newStr;
   	}

   	for(var i=0; i < $('.amount').length; i++){
		$('.amount').eq(i).val('1')
	}

  if($('.main').children().length == 0){
          
    console.log('корзина пуста')
    $('.container').remove()
    $('h2').remove()
    $('h1').add('<div class="emptyBasket"><h2>Корзина пуста</h2><p>Задизайните адресник на главной странице</p></div>').appendTo( document.body )
    
  }

  //заменить массивом и значением 
	function calculate(){
		var summ = 0
		var elems = $('.amountInput')
		for (var i = 0; i < elems.length; i++){
			if(elems.eq(i).css('display') != 'none'){
				summ = summ + parseInt(elems.eq(i).val())
			}
			
		}

		var elems2 = $('.amount')
		for(var i=0; i < elems2.length; i++){
			if(elems2.eq(i).css('display') != 'none'){
				summ = summ + parseInt(elems2.eq(i).val())
			}
		}

		$('#count').text(summ);
		$('#costValue').text(summ * 450)

	}

  //подстановка значений для изменения
  // console.log(context)



   	$('.delete').click(function(){

   		$('.popupDelete').show()
   		$('.deleteProove').show()

   		that = this; 

   	})

    $('.change').click(function(){
      console.log('change', $(this).parent().parent().parent())
      console.log($('.item').index($(this).parent().parent().parent()))

      $('#changeNumber').val($('.item').index($(this).parent().parent().parent()))
    }) 

   	$('#x').click(function(){

   			$('.popupDelete').hide()
   		 	$('.deleteProove').hide()

   		})

   	$('#deleteButton').click(function(){
   			
   			$('.popupDelete').hide()
   		 	$('.deleteProove').hide()
        var indexitem = $('.item').index($(that).parent().parent().parent())
        console.log(data[indexitem])
        // console.log($(that).parent().parent().parent())

        data.splice(indexitem, 1)
        console.log(data) 
        //добавление в сторадж новых данных, без удаленного элемента
        $.post(
         "/changeall/",
         {
           "csrfmiddlewaretoken" : csrftoken,
           'data': JSON.stringify(data)
         },
         function(){
          console.log('добавлено')
          
         }
        );

   			$(that).parent().parent().parent().remove()

   			if($('.main').children().length == 0){
   				
   				console.log('корзина пуста')
   				$('.container').remove()
   				$('h2').remove()
   				$('h1').add('<div class="emptyBasket"><h2>Корзина пуста</h2><p>Задизайните адресник на главной странице</p></div>').appendTo( document.body )
   				
   			}
   			
   		})

   	mainlength = $('.main').children().length
   	
	$('#count').text(mainlength);
	$('#costValue').text(mainlength * 450)

  //ловит изменения 
	var target = $('.main')[0]

	var observer = new MutationObserver(function(mutations) {
		mutations.forEach(function(mutation) {
			//просчитать новое значение количества и сумму
  			calculate()

  		});    
	});
 
	// создаем конфигурации для наблюдателя
	var config = { attributes: true, childList: true, characterData: true };
 
	// запускаем механизм наблюдения
	observer.observe(target,  config);

	//ловит изменение значения в input select
	$('select.amount').on('change', function() {
  		// $('input[name="city"]').val();
  		var amountLength = parseInt(this.value)
      
  		// console.log(typeof(this.value), this.value)
  		
  		if(this.value == '3+'){
  			//показать input, где можно писать только цифры
  			// $('.UpOverPriceText').show()
  			$(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').show()
  			$(this).hide()
  			$(this).parent().children('.amountInput').show()
        $(this).parent().children('.amountInput').val('1')
  			$(this).parent().parent().children('.UpOverPrice').children('.overPrice').text(parseInt($(this).parent().children('.amountInput').val()) * 450) 
  			$(this).parent().children('.piece').show()
        // console.log(1, $('.item').index($(this).parent().parent()))
        
    
        data[$('.item').index($(this).parent().parent())]['amount'] = 1
        // console.log(data[$('.item').index($(this).parent().parent())])
        $('#dataform').val(JSON.stringify(data))
  		}else{
        // 
        // console.log(amountLength, $('.item').index($(this).parent().parent()))
        data[$('.item').index($(this).parent().parent())]['amount'] = amountLength
        $('#dataform').val(JSON.stringify(data))
        // console.log(data[$('.item').index($(this).parent().parent())])	
  			$(this).parent().parent().children('.UpOverPrice').children('.overPrice').text(amountLength * 450)
  		}

  		if(amountLength > 1){
  			// console.log('ttttt')
  			$(this).parent().children('.piece').show()
  			$(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').show()
  		}else{
  			$(this).parent().children('.piece').hide()
  			$(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').hide()

  		}

  		//просчитать новое значение количества и сумму
  		calculate()		

	});

  //ловит изменение значения в input 
	$('.amountInput').on('change', function(){
		
		var value = parseInt(this.value)
    // console.log(value)   
    data[$('.item').index($(this).parent().parent())]['amount'] = value
    // console.log(data[$('.item').index($(this).parent().parent())])
    // console.log(data)
    $('#dataform').val(JSON.stringify(data))
    
    
		if(value >= 1 && value <= 10){
		    
  			$(this).parent().parent().children('.UpOverPrice').children('.overPrice').text(value * 450)

  			if(value == 1){
				  $(this).parent().children('.piece').hide()
				  $(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').hide()
			     }else{
				      $(this).parent().children('.piece').show()
				      $(this).parent().parent().children('.UpOverPrice').children('.UpOverPriceText').show()
			   }
		}
		//просчитать новое значение количества и сумму
		calculate()	
  		
	})

  // $('.registration button').click(function(){
  //   console.log('click')
  // })
  console.log(data)
   

})