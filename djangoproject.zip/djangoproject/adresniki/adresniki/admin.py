from django.contrib import admin 
from django.contrib.sessions.models import Session
from .models import Client, Order, OrderNomer

class OrderInline(admin.TabularInline):
	model = Order

# class ClientInline(admin.TabularInline):
# 	model = Client

class ClientAdmin(admin.ModelAdmin):
	list_display=('id', 'email', 'firstname', 'lastname')
	search_fields = ('id',)
	inlines = [
		OrderInline,
	]
	

class OrderAdmin(admin.ModelAdmin):

	list_display=('id','pay', 'does', 'done', 'packed', 'shipped', 'client') #отображение полей в списке, можно вызывать функцию
	list_editable=('pay', 'does', 'done', 'packed', 'shipped') #редактирование 
	list_filter=('pay', 'does', 'done', 'packed', 'shipped', 'date_pay') #фильтрация по полям
	readonly_fields = ('date_create', 'date_pay')
	search_fields = ('id',) #поиск по полю
	# inlines = [
	# 	ClientInline,
	# ]
	raw_id_fields = ('client',)
	# date_hierarchy = ('date_pay')

class OrderNomerAdmin(admin.ModelAdmin):

	list_display=('id','pay', 'does', 'done', 'packed', 'shipped', 'client') #отображение полей в списке, можно вызывать функцию
	list_editable=('pay', 'does', 'done', 'packed', 'shipped') #редактирование 
	list_filter=('pay', 'does', 'done', 'packed', 'shipped', 'date_pay') #фильтрация по полям
	readonly_fields = ('date_create', 'date_pay')
	search_fields = ('id',) #поиск по полю
	# inlines = [
	# 	ClientInline,
	# ]
	raw_id_fields = ('client',)
	# date_hierarchy = ('date_pay')
	

# admin.site.register(Users)
admin.site.register(Session)
admin.site.register(Client, ClientAdmin)
admin.site.register(Order, OrderAdmin)
admin.site.register(OrderNomer, OrderNomerAdmin)