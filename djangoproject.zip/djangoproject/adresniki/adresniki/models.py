# -*- coding:utf-8 -*-
from django.db import models
from django.core.validators import MaxValueValidator
from django.utils import timezone

class Client(models.Model):
	firstname = models.CharField(max_length=75)
	lastname = models.CharField(max_length=75)
	address = models.TextField(max_length=500) 
	#обработчики для err валидации
	apart_numb = models.PositiveIntegerField(validators=[MaxValueValidator(10000)])
	email = models.EmailField(max_length=75)
	tel = models.CharField(max_length=17)

	
	def __str__(self):
		return u"%s %s %s %s" % (self.id, self.firstname, self.lastname, self.email)

	# def __unicode__(self):
	# 	return u'%s %s %s %s %s %s' % (self.address, self.apart_numb, self.tel)

class Order(models.Model):
	client = models.ForeignKey(Client, on_delete=models.CASCADE)
	data = models.TextField(max_length=5000)
	pay = models.BooleanField(default=False)
	does = models.BooleanField(default=False)
	done = models.BooleanField(default=False)
	packed = models.BooleanField(default=False)
	shipped = models.BooleanField(default=False)
	date_create = models.DateTimeField('Дата создания',auto_now_add=True, null=True)
	date_pay = models.DateTimeField('Дата оплаты', blank=True, null=True)

	# def getobj(obj):
	# 	print('fefaefaefaef')
	# 	return obj

	# def __unicode__(self):
	# 	return u'%s %s %s %s %s' % (self.data, self.client , self.date_pay, self.date_create)

	# def __str__(self):
	# 	return u'%s' % (self.client)	

	def save(self, *args, **kwargs):
		print('kuku')
		if self.pay:
			print('pay is true')
			self.date_pay = timezone.now()
		return super().save(*args, **kwargs)

class OrderNomer(models.Model):
	client = models.ForeignKey(Client, on_delete=models.CASCADE)
	data = models.TextField(max_length=5000)
	pay = models.BooleanField(default=False)
	does = models.BooleanField(default=False)
	done = models.BooleanField(default=False)
	packed = models.BooleanField(default=False)
	shipped = models.BooleanField(default=False)
	date_create = models.DateTimeField('Дата создания',auto_now_add=True, null=True)
	date_pay = models.DateTimeField('Дата оплаты', blank=True, null=True)

	# def getobj(obj):
	# 	print('fefaefaefaef')
	# 	return obj

	# def __unicode__(self):
	# 	return u'%s %s %s %s %s' % (self.data, self.client , self.date_pay, self.date_create)

	# def __str__(self):
	# 	return u'%s' % (self.client)	

	def save(self, *args, **kwargs):
		print('kuku')
		if self.pay:
			print('pay is true')
			self.date_pay = timezone.now()
		return super().save(*args, **kwargs)

	




