"""adresniki URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views
 


urlpatterns = [
    path('admin/', admin.site.urls), 
    path('', views.main, name='main.html'),
    # path('toBasketButton/', views.toBasketButton), 
    path('basket/', views.basket, name='basket.html'),
    path('getall/', views.getAll),
    path('changeall/', views.changeAll),
    path('order/', views.order, name='order.html'),
    path('created/', views.created, name='created.html'),
    path('sendemailreq/', views.send), 
    path('nomer/', views.nomer, name='nomer.html'),
    path('brelok/', views.brelok, name='brelok.html'),
    path('order_autonomer/', views.order_autonomer, name='order_autonomer.html'),
    path('getallnomer/', views.getAllnomer),
    path('changeallnomer/', views.changeAllnomer),
    path('creatnomerorder/', views.createNomerOrder, name='creatednomer.html'),
    path('sendnomeremail/', views.sendNomerEmail)


    # path('comments/', views.comments, name='comments_template.html'),
]
