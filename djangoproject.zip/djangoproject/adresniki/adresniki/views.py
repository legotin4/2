# -*- coding:utf-8 -*-
from django.http import HttpResponse, JsonResponse
from django.template import loader
from django.shortcuts import redirect, reverse
from . import models
import json
from django.core.mail import EmailMessage, EmailMultiAlternatives

def main(request):
	template = loader.get_template('main.html')
	if request.method == 'POST':
		changeNumber = request.POST['changeNumber']
		print(changeNumber)
		# request.session['changeNumber'] = changeNumber
		data = request.session.get('data')
		# data = json.loads(data)
		item = data[int(changeNumber)]
		print(item)
		context = {
			'textUp' : item['textup'],
			'textDown' : item['textdown'],
			'color' : item['color'],
			'formtag' : item['form'], 
			'changeNumber': int(changeNumber), 
			'data': data
		}

		return HttpResponse(template.render(context, request))

	data = request.session.get('data')
	# data = json.loads(data)
	context = {
		'data' : data
	}
	return HttpResponse(template.render(context, request))

# def toBasketButton(request):
	# print('вот здесь вот')
	
	# if request.method == 'POST':
		# data = json.loads(request.POST['allstr'])
		# data = request.POST['allstr']
		# print(data)
		# request.session['data'] = data
		# print(data)
		# context = {
			# 'data' : data
		# }
		# template = loader.get_template('basket.html')
		# return HttpResponse(template.render(context, request))
		# basket(request, data)
		# return redirect(basket)

def basket(request):
	template = loader.get_template('basket.html')
	# data = json.loads(data)

	# if request.method == 'POST':
	# 	data = request.POST['data']
	# 	print(data)
	# 	data = json.loads(data)
	# 	request.session['data'] = data
	# 	# data = request.session.get('data')
	# 	context = {
	# 		'data' : data
	# 	}
	# 	return HttpResponse(template.render(context, request))



	data = request.session.get('data')
	# print(data)
	# data = json.loads(data)
	# print(data)
	context = {
		'data' : data
	}
	return HttpResponse(template.render(context, request))
	# return render(request, 'basket.html', context)

def getAll(request):
	if request.method == 'POST' and request.is_ajax():
		data = request.session.get('data')
		return JsonResponse(data, safe=False)

def changeAll(request):
	if request.method == 'POST' and request.is_ajax():
		data = request.POST['data']
		print(data)
		data = json.loads(data)
		request.session['data'] = data
		print(request.session.get('data'), '--------->')
		return JsonResponse(True, safe=False)

def order(request):
	template = loader.get_template('order.html')

	if request.method == 'POST':
		data = request.POST['data']
		# print(changeNumber)
		# data = json.loads(data)
		request.session['data'] = data
		print(request.session.get('data'))
		#дописать так же как в корзине сколько всего и какие адресники
		# request.session['changeNumber'] = changeNumber
		# data = request.session.get('data')
		# data = json.loads(data)
		# item = data[int(changeNumber)]
		# print(item)
		# context = {
		# 	'textUp' : item['textup'],
		# 	'textDown' : item['textdown'],
		# 	'color' : item['color'],
		# 	'formtag' : item['form'], 
		# 	'changeNumber': int(changeNumber), 
		# 	'data': data
		# }

		context = {
		
		}

		return HttpResponse(template.render(context, request))


	context = {
		
	}
	return HttpResponse(template.render(context, request))

def created(request):
	
	if request.method == 'POST':
		template = loader.get_template('created.html')
		
		data = request.session.get('data') 
		# print(type(data))
		data = json.dumps(data)
		# print(type(data))

		newClient = models.Client()
		newClient.firstname = request.POST['firstname']
		newClient.lastname = request.POST['lastname']
		newClient.address = request.POST['address']
		newClient.apart_numb = request.POST['apart']
		newClient.email = request.POST['email']
		newClient.tel = request.POST['telephone']
		newClient.save()

		newOrder = models.Order()
		newOrder.data = data
		newOrder.client = newClient
		newOrder.save()

	context = {

	}

	# send(newClient, newOrder)

	return HttpResponse(template.render(context, request))

def sendemailreq(request):
	# email = EmailMessage(
	# 	'Hello',
	# 	'Body goes here',
	# 	'legotin74two@gmail.com',
	# 	['legotin4@yandex.ru'],
	# 	# reply_to=['another@example.com'],
	# 	headers={'Message-ID': 'foo'},
	# )


	#Номер заказа
	# order.id
	#Адресс доставки
	# client.address 
	#Получатель
	# client.firstname, client.lastname
	#Способ доставки
	# 'Почта России'
	#Стоимость изготовления
	# проход по всем ...



	#Стоимость доставки
	
	#Сумма к оплате 

	#Адресники:
	#перечесление, колонки: 1) тип (с пикчей) 2) надпись сверху, сзнизу 3) количество шт. 4) общая стоимость


	subject, from_email, to = 'hello', 'legotin74two@gmail.com', 'legotin4@yandex.ru'
	text_content = 'This is an important message.'
	html_content = '<p>This is an <strong>important</strong> message.</p>'
	msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
	msg.attach_alternative(html_content, "text/html")
	msg.send()

	# email.send(fail_silently=False)
	print('send')
	context = {

	}

	return HttpResponse(context, request)
# client, order
def send(request):
	client = models.Client.objects.get(id=20)
	order = models.Order.objects.get(id=22)
	# print(client)
	print(order.id, 'номер заказа', order.data, type(order))
	print(type(order.data))
	data = json.loads(order.data)
	print(type(data))
	# data = order.data
	# print(data, type(data))
	cost = 0
	for item in data:
		print(item['amount'], type(item['amount']))
		cost = cost + item['amount']
	print(cost)
	# полная стоимость изготавления
	cost = cost * 450 
	print(cost)

	#Адресники:
	#перечесление, колонки: 1) тип (с пикчей) 2) надпись сверху, сзнизу 3) количество шт. 4) общая стоимость
	html_content = "<table style='max-width:600px;' width='100%' align='center'><tr><td style='font-size:26px;font-weight:normal; padding:0 24px 24px 0px'>Адресники с гравировкой</td></tr></table>\
	<table style='max-width:600px;' width='100%' align='center'><tr><td style='font-size:21px;font-weight:normal; padding:0 24px 24px 0px'>Заказ принят и ждёт оплаты</td></tr></table>\
	<table style='max-width:600px;' width='100%' align='center'><tr><td style='padding:0 24px 24px 0px'>Здраствуйте, {firstname}!<br>Мы приняли в работу ваш заказ и начнём изготавливать адресники как только поступит оплата! Проверьте всё ли верно:  </td></tr></table>\
	<table style='padding:0 24px 24px 0px; max-width:600px;' width='100%' align='center'>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Номер заказа</td><td style='padding: 0 12px 12px 0;'>{orderid}</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Адрес доставки</td><td style='padding: 0 12px 12px 0;'>{address}</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Получатель</td><td style='padding: 0 12px 12px 0;'>{firstname} {lastname}</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Способ доставки</td><td style='padding: 0 12px 12px 0;'>Почта России</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Стоимость изготовления</td><td style='padding: 0 12px 12px 0;'>{cost} &#8381;</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Стоимость доставки</td><td style='padding: 0 12px 12px 0;'>Бесплатно</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Сумма к оплате</td><td style='padding: 0 12px 12px 0;'>{cost} &#8381;</td>\
	</tr>\
	</table>\
	<table style='max-width:600px;' width='100%' align='center'><tr><td style='font-size:21px;font-weight:normal; padding:0 24px 12px 0px'>Адресники:</td></tr></table>\
	".format(					orderid = order.id, 
					address = client.address, 
					firstname = client.firstname, 
					lastname = client.lastname,
					cost = cost

					)

	texttd = '<table style="border-bottom-color: #d7d7d7; border-bottom-style: solid; border-bottom-width: 1px; padding:0 24px 24px 24px; max-width:600px; border-collapse: collapse;"  width="100%" align="center">'
	for item in data:
		if item['form'] == 'rect':
			# src = 'http://127.0.0.1:8000/static/basket/rect2-min.svg'

			# src = 'https://s587sas.storage.yandex.net/rdisk/99a1380a3d9c3efff51ba09d508528a9f5830c69d16d44377ed96fbf41aa15be/5f42ecdf/SR4qRZvCtP0ve2KNzWl1Plh2eULFp8R--oN-KsiYsni6igw7vz6GA0R6Sy6cnS2Zz7-8AwigdkF9Xpb5VO9fUQ==?uid=0&filename=rect2-min.svg&disposition=attachment&hash=&limit=0&content_type=image%2Fsvg%2Bxml&tknv=v2&owner_uid=111000772&hid=083b471599bc0d3e569e0e507dcda99b&etag=9142b31f8af193e5359289fce93fe2c2&fsize=2721&media_type=image&rtoken=REA2oNEqsFni&force_default=no&ycrid=na-f96a9b3d43f8fdbd39841b623e9ba26c-downloader13e&ts=5ad92f2ddb5c0&s=bde0f717a3e667a7fb829d1ce5edeb89304dbcb08766673310a91880105e0a6a&pb=U2FsdGVkX1_AEy1LDmqLzdBvK4gKFzQvUNkP12qLkIAfw5ROlSnNKMaLNuAoN27V4Z_oQK97duJG17nd_FJilApg-ZFAY3mZA6qHJOr8sHY'
			src = 'https://downloader.disk.yandex.ru/preview/60abae8d1d8dd97ab59cbbd711f1da71cf9b13d6bb53fd4247c925aea4ff4a65/5f454a7f/Ib6Mgkcnu0FKrn4yR_J_-yCvWc1gwGrcVk2Gi7Qr39R6Nn0-nYev4yHUgSKIr264iBW8b9O-yyB_wR-jx3MDpA==?uid=0&filename=rect2-min.svg&disposition=inline&hash=&limit=0&content_type=image%2Fjpeg&tknv=v2&owner_uid=111000772&size=2048x2048'
		
		elif item['form'] == 'circle':
			# src = 'http://127.0.0.1:8000/static/basket/circle2-min.svg'

			# src = 'https://s151vla.storage.yandex.net/rdisk/6808e54ebe86ad5cd1871ed79db89ce42ffa551e267482a1ee8771c7b4ba2332/5f42ec6b/SR4qRZvCtP0ve2KNzWl1PspSZ6J1tWbnceKOEYP3N0XnPCzMFNY-UAHtiqjfAON8SeiNfW8tV1X1dgCfhUg5rA==?uid=0&filename=circle2-min.svg&disposition=attachment&hash=&limit=0&content_type=image%2Fsvg%2Bxml&tknv=v2&owner_uid=111000772&media_type=image&etag=2782b978019c81202f9dc5a8e1bda3b5&fsize=2676&hid=00c11650a445c748c15b5cc19053358f&rtoken=7KEDBMpd3vc1&force_default=no&ycrid=na-a005ae704edfe34e45986a60016f0e09-downloader13e&ts=5ad92ebf3b0c0&s=47d6a67f9ead224c9a862db5733444e35fafad747958f61710d243a238424aa9&pb=U2FsdGVkX19Sc-x5T9ii3HTADT95JoICklVo3OCsqjzrG2JaPoKPP-fmuZyEDjyCnuaK07JzQn6mQv1Qg_2H_94GLCRAogpnoMH5qZOGPvg'
			src = 'https://downloader.disk.yandex.ru/preview/fd8933b56f56b3396b1233039a0e5b15596f7b475eac62c7ebf7777f13133fe3/5f454a6d/jhcZgLol5x6u7esRFh0FziCvWc1gwGrcVk2Gi7Qr39TrQ89eCcCxmvNqmX2nCzsxzzGKZCH0oHMPS8h-tUIuWA==?uid=0&filename=circle2-min.svg&disposition=inline&hash=&limit=0&content_type=image%2Fjpeg&tknv=v2&owner_uid=111000772&size=2048x2048'
		
		elif item['form'] == 'oval':
			# src = 'http://127.0.0.1:8000/static/basket/oval2-min.svg'
			# src = 'https://s198sas.storage.yandex.net/rdisk/78b9ac6d47c81e947598c32a154c343d9e94442088f1d9341e30c246467aa0a6/5f42ecaa/SR4qRZvCtP0ve2KNzWl1PrZeOGHryaiOhfl3IEeIgyzeIVJk0ZfJOcpgaOuQ4W8udZSzHyBcKd1culy4MU_N5g==?uid=0&filename=oval2-min.svg&disposition=attachment&hash=&limit=0&content_type=image%2Fsvg%2Bxml&tknv=v2&owner_uid=111000772&fsize=2676&etag=d9a87b00e2663eb02ae5194bdb02700c&hid=a8d72bcfde66a29362d8df810645bec8&media_type=image&rtoken=426PQaUCWQvW&force_default=no&ycrid=na-bef55af931bdb6a4d6fe5aab4b5ccf42-downloader13e&ts=5ad92efb4fe80&s=fdbcfc156ce7a704b656bce82948c7d5d222a1f7695c31afe0ffbc78d03057cc&pb=U2FsdGVkX188RbEhAlRY4XSRezbVdSl6X3Ea2aoAsWcKTPWlgrOrVEMWpt2-MNDFe4jm5VpC0WhP66rojEAd8wkVmymPg_6uMyXGfzIKFL8'
			src = 'https://downloader.disk.yandex.ru/preview/43a2342a0cbbafe6d604ab3193c7da1d4786173ae5a8cea010751610909f77d6/5f454a75/R0l3heFwWdRpN_Hm2ITEGiCvWc1gwGrcVk2Gi7Qr39SZQ1ciKy-f38iIs2-TLqHv8INxjJpSiemTQTigrTAukg==?uid=0&filename=oval2-min.svg&disposition=inline&hash=&limit=0&content_type=image%2Fjpeg&tknv=v2&owner_uid=111000772&size=2048x2048'

		texttd = texttd + '<tr style="border-left-color: #d7d7d7; border-left-style: solid; border-left-width: 1px; border-right-color: #d7d7d7; border-right-style: solid; border-right-width: 1px; border-top-color: #d7d7d7; border-top-style: solid; border-top-width: 1px;"><td style="padding-left: 12px; padding-top: 12px; padding-bottom: 12px;"><img width="100px" height="70px" alt="Незагрузилось" src="{src}"/></td> <td><span style="color:#b4bcc4; font-size:12px;">Гравировка</span> <br>{up}<br>{down}</td> <td>{amount} шт.</td> <td> {price} &#8381;</td></tr>'.format(src = src, up = item['textup'], down = item['textdown'], amount = item['amount'], price = item['amount'] * 450)
		# texttd = texttd + texttd

	table = texttd + '</table>'

	print(table)
	html_content = html_content + table

	subject, from_email, to = 'hello', 'legotin74two@gmail.com', 'legotin4@yandex.ru'
	text_content = 'This is an important message.'
	# html_content = '<p>This is an <strong>important</strong> message.</p>'
	msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
	msg.attach_alternative(html_content, "text/html")
	msg.send()
	# template = '<p>This is an <strong>important</strong> message.</p>'
	# msg = EmailMultiAlternatives(subject, text_content, from_email, [to])
	# msg.attach_alternative(html_content, "text/html")
	# msg.send()


def nomer(request):
	template = loader.get_template('nomer.html')

	datanomer = request.session.get('datanomer')
	print(datanomer, 'datanomer')
	if datanomer == None:
		datanomer = 'undefined' 
	context = {
		'datanomer': datanomer 
	}
	
	return HttpResponse(template.render(context, request))

def brelok(request):
	template = loader.get_template('brelok.html')

	context = {

	}
	
	return HttpResponse(template.render(context, request))



def order_autonomer(request):
	template = loader.get_template('order_autonomer.html')
	datanomer = request.session.get('datanomer')
	print(datanomer, 'datanomer')
	context = {
		'datanomer': datanomer 
	}
	
	return HttpResponse(template.render(context, request))



def getAllnomer(request):
	if request.method == 'POST' and request.is_ajax():
		datanomer = request.session.get('datanomer')
		return JsonResponse(datanomer, safe=False)

def changeAllnomer(request):
	if request.method == 'POST' and request.is_ajax():
		datanomer = request.POST['datanomer']
		print(datanomer)
		datanomer = json.loads(datanomer)
		request.session['datanomer'] = datanomer
		print(request.session.get('datanomer'), '--------->')
		return JsonResponse(True, safe=False)

def createNomerOrder(request):
	
	if request.method == 'POST':
		template = loader.get_template('creatednomer.html')
		
		data = request.session.get('datanomer') 
		# print(type(data))
		data = json.dumps(data)
		# print(type(data))

		newClient = models.Client()
		newClient.firstname = request.POST['firstname']
		newClient.lastname = request.POST['lastname']
		newClient.address = request.POST['address']
		newClient.apart_numb = request.POST['apart']
		newClient.email = request.POST['email']
		newClient.tel = request.POST['telephone']
		newClient.save()

		newOrder = models.OrderNomer()
		newOrder.data = data
		newOrder.client = newClient
		newOrder.save()

	context = {

	}

	# send(newClient, newOrder)

	return HttpResponse(template.render(context, request))

def sendNomerEmail(request):
	client = models.Client.objects.get(id=22)
	order = models.OrderNomer.objects.get(id=2)
	data = json.loads(order.data)

	print(type(data))
	cost = 0
	for item in data:
		print(item['amount'], type(item['amount']))
		cost = cost + item['amount']
	# print(cost)
	# полная стоимость изготавления
	cost = cost * 350 
	print(cost)

	html_content = "<table style='max-width:600px;' width='100%' align='center'><tr><td style='font-size:26px;font-weight:normal; padding:0 24px 24px 0px'>Автономер-брелок</td></tr></table>\
	<table style='max-width:600px;' width='100%' align='center'><tr><td style='font-size:21px;font-weight:normal; padding:0 24px 24px 0px'>Заказ принят и ждёт оплаты</td></tr></table>\
	<table style='max-width:600px;' width='100%' align='center'><tr><td style='padding:0 24px 24px 0px'>Здраствуйте, {firstname}!<br>Мы приняли в работу ваш заказ и начнём изготавление как только поступит оплата! Проверьте всё ли верно:  </td></tr></table>\
	<table style='padding:0 24px 24px 0px; max-width:600px;' width='100%' align='center'>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Номер заказа</td><td style='padding: 0 12px 12px 0;'>{orderid}</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Адрес доставки</td><td style='padding: 0 12px 12px 0;'>{address}</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Получатель</td><td style='padding: 0 12px 12px 0;'>{firstname} {lastname}</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Способ доставки</td><td style='padding: 0 12px 12px 0;'>Почта России</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Стоимость изготовления</td><td style='padding: 0 12px 12px 0;'>{cost} &#8381;</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Стоимость доставки</td><td style='padding: 0 12px 12px 0;'>Бесплатно</td>\
	</tr>\
	<tr>\
		<td style='color:#808285; padding: 0 12px 12px 0px;'>Сумма к оплате</td><td style='padding: 0 12px 12px 0;'>{cost} &#8381;</td>\
	</tr>\
	</table>\
	<table style='max-width:600px;' width='100%' align='center'><tr><td style='font-size:21px;font-weight:normal; padding:0 24px 12px 0px'>Автономера:</td></tr></table>\
	".format(		
					orderid = order.id, 
					address = client.address, 
					firstname = client.firstname, 
					lastname = client.lastname,
					cost = cost
					)




	texttd = '<table style="border-bottom-color: #d7d7d7; border-bottom-style: solid; border-bottom-width: 1px; padding:0 24px 24px 24px; max-width:600px; border-collapse: collapse;"  width="100%" align="center">'

	for item in data:
		# '<div style="margin: 10px 10px; padding: 10px 10px; background-color: white; border-radius: 3px; border: 0.8px solid #8b8b8b2b;">\
		# 		<div style="margin-right: 20px;width: 132px;height: 38px;padding: 4px 8px 4px 8px;border: 1px solid #8b8b8b;border-radius: 3px;display: inline-block;vertical-align: middle;">\
		# 		<div style="float: left;margin-top: 8px;font-size: 22px;"><span>{nomer}</span>\
		# 		</div>\
		# 		<div style="float: right;">\
		# 				<div style="font-size: 12px;">\
		# 				<span>{code}</span>\
		# 			</div>\
		# 		<div><img style="width: 23px;height: 20px;" src="/static/nomer/flag.jpg">\
		# 		</div>\
		# 		</div>\
		# 		</div>\
		# 		<div style="display: inline-block;vertical-align: middle;">\
		# 			<div style="float: left;font-size: 12px;">\
		# 				<div style="font-size: 12px;"><span>{amount}</span> шт.</div>\
		# 				<div style="font-size: 12px; margin-top: 5px;">300 ₽/шт.</div>\
		# 			</div>\
		# 				<div style="float: left;margin-left: 20px;margin-top: 8px;font-weight: 500;"><span>{cost}</span> ₽\
		# 				</div>\
		# 		</div>\
		# 		<div style="clear: both;"></div>\
		# </div>\
		# '.format(nomer = item['nomer'], code = item['code'], amount = item['amount'], cost = item['amount'] * 350)

		texttd = texttd + '<tr style="border-left-color: #d7d7d7; border-left-style: solid; border-left-width: 1px; border-right-color: #d7d7d7; border-right-style: solid; border-right-width: 1px; border-top-color: #d7d7d7; border-top-style: solid; border-top-width: 1px;">\
			<td style="padding-left: 12px; padding-top: 12px; padding-bottom: 12px;">\
				<table style="margin: 10px 10px; padding: 10px 10px;">\
					<tr style="margin-right: 20px;width: 132px;height: 38px;padding: 4px 8px 4px 8px;border: 1px solid #8b8b8b;border-radius: 3px;display: inline-block;vertical-align: middle;">\
						<td style="float: left;margin-top: 8px;font-size: 22px;">{nomer}</td>\
						<td style="float: right; margin-top: -5px; margin-right: -5px;">\
							<table>\
								<tr ><td style="font-size: 12px;">{code}</td></tr>\
								<tr ><td><img style="width: 28px;" src="https://downloader.disk.yandex.ru/preview/eea6fa7fb657cd94daf8f2380ee0edabccfd8c9f5d5510ef89620d4ddaa99e0d/5f6b99b4/6t2rhfJOJHsfT5N22J80yIG_PR9WUVN9o0I9muTFqoqpEnD8uTwRm_FaDY2QiV3NYLUW986Kdm6WQlYkc52SFg==?uid=0&filename=flag.jpg&disposition=inline&hash=&limit=0&content_type=image%2Fjpeg&tknv=v2&owner_uid=111000772&size=2048x2048"></td></tr>\
							</table>\
						</td>\
					</tr>\
				</table>\
			</td>\
			<td style="padding-left: 12px; padding-top: 12px; padding-bottom: 12px;">\
				<table>\
					<tr>\
						<td style="font-size: 12px;">{amount} шт.</td>\
					</tr>\
					<tr>\
						<td style="font-size: 12px;">350 ₽/шт.</td>\
					</tr>\
				</table>\
			</td>\
			<td style="padding-left: 12px; padding-top: 12px; padding-bottom: 12px; font-weight: 500;">{cost} ₽</td>\
		</tr>'.format(nomer = item['nomer'], code = item['code'], amount = item['amount'], cost = item['amount'] * 350)

	table = texttd + '</table>'	
	html_content = html_content + table	

	subject, from_email, to = 'hello', 'legotin74two@gmail.com', 'legotin4@yandex.ru'
	msg = EmailMessage(subject, html_content, from_email, [to])
	msg.content_subtype = "html"  
	msg.send()








