from models import Order
from django.http import JsonResponse


order = Order.objects.get(id=22)

data = json.loads(order.data)
# '<table><tr>'
	# img надпись сверху, надпись снизу, количество шт, общая стоимость всех штук

	# http://127.0.0.1:8000/static/basket/rect2-min.svg
	# http://127.0.0.1:8000/static/basket/circle2-min.svg
	# http://127.0.0.1:8000/static/basket/oval2-min.svg



		# <td> <img alt='' src=''> </td> <td></td> <td></td> <td></td>

# '</tr></table>'

for item in data:
	if item['form'] == 'rect':
		src = 'http://127.0.0.1:8000/static/basket/rect2-min.svg'
	elif item['form'] == 'circle':
		src = 'http://127.0.0.1:8000/static/basket/circle2-min.svg'
	elif item['form'] == 'oval':
		src = 'http://127.0.0.1:8000/static/basket/oval2-min.svg'


	texttd = '<table><tr><td> <img alt="Незагрузилось" src={src}> </td> <td>{up}; {down}</td> <td>{amount} шт.</td> <td> {price} руб.</td>'.format(src = src, up = item['textup'], down = item['textdown'], amount = item['amount'], price = item['amount'] * 450)
	texttd = texttd + texttd

table = texttd + '</tr></table>'

print(table)

