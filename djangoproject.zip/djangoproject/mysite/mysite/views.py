from django.http import HttpResponse
from mysite.models import Link
from django.template import loader


def index(request):
	
	list_link = [[15, 23], [21, 22], [15, 21], [17, 20], [18, 19], [17, 18], [12, 17], [0, 16], [0, 15], [0, 14], [0, 13], [0, 12], [0, 11], [0, 10], [0, 9]]

	for elem in list_link:
		objectLink = Link()
		objectLink.ancestor = elem[0]
		objectLink.descendant = elem[1]
		objectLink.save()




	return HttpResponse("objectLink.save()")

def comments(request):

	
	link_all_object = Link.objects.all()

	#все ancestor без повторов -> ancestor_list
	ancestor_list= [] 
	for elem in link_all_object:
		if elem.ancestor not in ancestor_list:
			ancestor_list.append(int(elem.ancestor))

	#создается словарь ancestor: [множество descendant == ancestor] -> data
	data = {}
	for i in ancestor_list:
		descendant_list = []
		
		for elem in link_all_object:
			if elem.ancestor == i:
				descendant_list.append(int(elem.descendant))
		
		data[i] = descendant_list

	print('data', data) 

	#создается множество ancestor, descendant, descendant(для какогото эл. ancestor), ancestor 
	#все ancestor скопированы в tree. за аncestor в tree добавляется descendant
	tree = ancestor_list[:]
	tree = sorted(tree) 
	new_list_comment = []

	for item in tree:
		if item not in new_list_comment:
			new_list_comment.append(int(item))
		for elem in link_all_object:
			if elem.ancestor == item and elem.descendant not in new_list_comment:
				index = new_list_comment.index(item)
				index += 1
				new_list_comment.insert(index, int(elem.descendant))

	print(new_list_comment, 'tree')

	#создается массив на основе класса Link, [ancestor, descendant], none заменяются на 0
	
	list_link = []
	for i in link_all_object:
		if i.descendant == None:
			i.descendant = 0
		if i.ancestor == None:
			i.ancestor = 0 
		new = [int(i.ancestor), int(i.descendant)]
		list_link.append(new)

	template = loader.get_template('comments_template.html')
	context = {
		'ancestor_list': ancestor_list,
		'link_all_object': link_all_object,
		'data': data,
		'tree': new_list_comment,
		'list_link': list_link
	}
	print(ancestor_list)
	return HttpResponse(template.render(context, request))

	