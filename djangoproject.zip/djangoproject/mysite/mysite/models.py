from django.db import models
 
class Link(models.Model):
	#id_card = models.ForeignKey('CardProfessions')
	ancestor = models.IntegerField(null=True)
	descendant = models.IntegerField(null=True)

	def __unicode__(self):
		return u'%s %s' % (self.ancestor, self.descendant)

#users
class User(models.Model):
	id_tg = models.IntegerField(unique=True)
	bot = models.BooleanField(default=False)
	first_name = models.CharField(max_length=None)
	last_name = models.CharField(max_length=None)
	username = models.CharField(max_length=None) 
	phone = models.CharField(max_length=None)
	about = models.TextField() 
	profile_photo_path = models.CharField(max_length=None)

	def __unicode__(self):
		return u'%s %s %s %s %s %s %s %s' % (self.id_tg, self.bot, self.first_name, self.last_name, self.username, self.phone, self.about, self.profile_photo_path)


#message
class Message(models.Model):
	id_tg = models.IntegerField(unique=True)
	date = models.DateTimeField()
	message = models.TextField()
	from_id = models.IntegerField()##или ссылка к таблице юзер?
	media = models.BooleanField(default=False)
	media_path = models.CharField(max_length=None)
	reply_to_msg_id_tg = models.IntegerField()
	media_mime_type = models.CharField(max_length=None)
	media_file_name = models.CharField(max_length=None)

	#title_id = models.ForeignKey('CardProfessions') #при создание объекта - сделать инит - получение юзер объекта 
	#добавить от кого и ссылку к юзеру?
	#метод, который достоёт по фром_ид из юзер объект юзер и сохраняет в поле, или связывает с таблицей юзер




	def __unicode__(self):
		return u'%s %s %s %s %s %s %s %s' % (self.id_tg, self.date, self.message, self.media, self.media_path, self.reply_to_msg_id, self.media_mime_type, self.media_file_name)

#thread
class Thread(models.Model):
	pass


#tag for thread
class Tag(models.Model):
	description = models.TextField()
	name = models.CharField(max_length=None)
