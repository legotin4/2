from django.contrib import admin 
from .models import Link, Users, Message 

class LinkAdmin(admin.ModelAdmin):
	list_display=('ancestor', 'descendant')

admin.site.register(Link, LinkAdmin)
admin.site.register(Users)
admin.site.register(Message)


