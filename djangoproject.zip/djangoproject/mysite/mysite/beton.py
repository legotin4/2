
def lenta(len1, len2, width, hight):
	len1 = len1 * 2
	len2 = len2 * 2
	lenall = len2 + len1
	print lenall * width * hight


def plita(len1, len2, hight):
	s = len1 * len2
	print s * hight

print('лента')
print('14*14')
lenta(14, 14, 0.5, 0.8)
print('7*11')
lenta(7, 11, 0.5, 0.8)
lenta(7, 11, 0.4, 0.8)

print('плита')
print('14*14')
plita(14, 14, 0.2)
print('7*11')
plita(7, 11, 0.2)