$( document ).ready(function() {
    console.log( "ready!" );
   /*формат() как в питоне заменяет %s значениемя по очереди*/
	String.prototype.format = function() {
    var newStr = this, i = 0;
    while (/%s/.test(newStr))
        newStr = newStr.replace("%s", arguments[i++])

    return newStr;
   }
  
  //делает дерево комментов
	$(".comment").each(function(indx, element){
		for (var i = 0; i < list_link.length; i++){
			if($(element).attr('id') == list_link[i][1]){
				if(list_link[i][1] == 0){
					break
				}

				if($(element).parent().prev().children('p').attr('id') == list_link[i][0]){
					margin = $(element).parent().prev().css("margin-left") 
          			margin = parseInt(margin, 10)
         			margin = margin + 10
          			$(element).parent().css("margin-left", "%spx".format(margin))
				}else{
              		margin = $('[id = %s]'.format(list_link[i][0])).parent().css("margin-left")
              		margin = parseInt(margin, 10)
              		//console.log(margin)
              		margin = margin + 10
              		$(element).parent().css("margin-left", "%spx".format(margin))
              	}

			}
		}
	});
});